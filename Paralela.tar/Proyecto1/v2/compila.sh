g++ main.cpp -std=c++11 -march=native -fopenmp -O3 -lm
./a.out 8 1000
./a.out 10 10000